# -*- coding: utf-8 -*-
# Mire Sirens: this file used to hold all of Trakt's own caching (watched/progress sync,
# calendar, activity tracking, etc.) alongside a few generic utilities that got reused
# elsewhere. Now that trakt_api.py/trakt_lists.py are gone, everything Trakt-specific here
# has been pruned - what's left is genuinely still in use: list_id custom-sort storage
# (shared with MDBList's My Lists via indexers/mdblist_lists.py) and a generic
# "clear cached data" utility (service.py's periodic cleanup + the Clear Cache settings
# menu). Kept at this path/filename so the existing import sites don't need to change;
# the physical 'trakt_db'/'trakt_data' table name is unchanged for the same reason
# mdblist_cache.py gives for reusing it - no functional upside to a migration.
from caches.base_cache import connect_database
from modules.kodi_utils import confirm_dialog

def set_list_custom_sort(list_id, data):
	string = 'trakt_list_custom_sort_%s' % list_id
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('INSERT OR REPLACE INTO trakt_data (id, data) VALUES (?, ?)', (string, repr(data)))
		return True
	except: return False

def delete_list_custom_sort(list_id):
	string = 'trakt_list_custom_sort_%s' % list_id
	try:
		dbcon = connect_database('trakt_db')
		dbcon.execute('DELETE FROM trakt_data WHERE id=?', (string,))
		return True
	except: return False

def get_list_custom_sort(list_id):
	string = 'trakt_list_custom_sort_%s' % list_id
	try:
		dbcon = connect_database('trakt_db')
		cache_data = dbcon.execute('SELECT data FROM trakt_data WHERE id = ?', (string,)).fetchone()
		return eval(cache_data[0])
	except: return {}

def get_all_lists_custom_sort():
	try:
		dbcon = connect_database('trakt_db')
		all_cache_data = dbcon.execute('SELECT data FROM trakt_data WHERE id LIKE %s' % "'trakt_list_custom_sort_%'").fetchall()
		all_cache_data = (eval(i[0]) for i in all_cache_data)
		return dict([(i['list_id'], {'sort_by': i['sort_by'], 'sort_how': i['sort_how']}) for i in all_cache_data])
	except: return {}

def clear_all_trakt_cache_data(silent=False, refresh=True):
	# Mire Sirens: the refresh-triggered background trakt_sync_activities() call has been
	# removed - it was the last reachable live Trakt API call left in the addon (triggered
	# via the "Clear Cache" menu). This table is now also where MDBList's own cache lives
	# (see mdblist_cache.py), so clearing it still does something useful.
	#
	# BUGFIX: this used to be one big try/except around everything, in this order: (1) a
	# maincache_db lookup/cleanup for stale 'trakt_lists_with_media_%' entries, THEN (2)
	# the actual trakt_data DELETE that clears MDBList's cache. If step 1 ever threw for
	# any reason, the whole function returned False before step 2 ever ran — silently, with
	# no notification either way (base_cache.clear_cache only notifies on success). That
	# would look exactly like "Clear MDBList Cache did nothing" with zero visible error.
	# Reordered so the actually-important trakt_data clear happens FIRST, in its own
	# protected block, so a failure in the secondary main_cache housekeeping can never
	# block it — and its own success/failure is tracked independently.
	#
	# FURTHER BUGFIX: reported that this returns "success" suspiciously fast compared to
	# other cache-clear options, and suspected it isn't actually doing anything. Verified
	# the DELETE logic itself against a real sqlite3 database (outside Kodi) and it does
	# correctly remove curated-list/collection/watchlist/etc cache rows while preserving
	# list-sort entries — the SQL itself isn't the bug. Rather than keep asserting that and
	# asking for another blind retest, this now reports the exact row count it removed in
	# its own notification (instead of base_cache.clear_cache's generic "Success"), so it's
	# directly verifiable rather than another "trust me" claim.
	start = silent or confirm_dialog()
	if not start: return False
	mdblist_cleared, cleared_count = False, 0
	try:
		dbcon = connect_database('trakt_db')
		for table in ('progress', 'watched', 'watched_status'): dbcon.execute('DELETE FROM %s' % table)
		try: cleared_count = dbcon.execute('SELECT COUNT(*) FROM trakt_data WHERE id NOT LIKE %s' % "'trakt_list_custom_sort_%'").fetchone()[0]
		except: cleared_count = 0
		dbcon.execute('DELETE FROM trakt_data WHERE id NOT LIKE %s' % "'trakt_list_custom_sort_%'")
		dbcon.execute('VACUUM')
		mdblist_cleared = True
	except: pass
	try:
		from caches.main_cache import main_cache
		main_cache_dbcon = connect_database('maincache_db')
		lists_with_media = main_cache_dbcon.execute('SELECT id FROM maincache WHERE id LIKE %s' % "'trakt_lists_with_media_%'").fetchall()
		for item in lists_with_media:
			try: main_cache.delete(item[0])
			except: pass
		main_cache.clean_database()
	except: pass
	if not silent:
		from modules.kodi_utils import notification
		notification(('Cleared %s MDBList cache entries' % cleared_count) if mdblist_cleared else 'MDBList cache clear failed', 4000)
	return mdblist_cleared
