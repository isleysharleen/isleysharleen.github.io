# -*- coding: utf-8 -*-
# Mire Sirens: MDBList-backed replacement for the portable subset of trakt_lists.py.
#
# NOT ported here (no MDBList equivalent - see apis/mdblist_api.py's comment block for
# why): Liked Lists, Like/Unlike a list, "In [X] Lists" (which public lists a movie/show
# appears in). Trakt's separate "Trending User Lists" / "Popular User Lists" browses are
# collapsed into one get_mdblist_popular_lists() below (MDBList only exposes lists/top,
# a single "sorted by Trakt likes" feed - not two distinct facets).
import os
import sys
import json
from threading import Thread
from random import shuffle
from apis.mdblist_api import (mdblist_search_lists, mdblist_get_my_lists, mdblist_get_popular_lists,
	mdblist_list_contents, mdblist_make_new_list, mdblist_delete_list)
from caches.trakt_cache import get_all_lists_custom_sort, set_list_custom_sort, delete_list_custom_sort
from indexers.movies import Movies
from indexers.tvshows import TVShows
from modules import kodi_utils
from modules.utils import paginate_list, gen_md5
from modules.settings import paginate, page_limit, widget_hide_next_page, jump_to_enabled
# logger = kodi_utils.logger

def search_mdblist_lists(params):
	def _builder():
		for item in lists:
			try:
				list_id, list_name, user, item_count = item['id'], item['name'], item['user_name'], item['items']
				display = '%s | [I]%s (x%s)[/I]' % (list_name, user, str(item_count))
				url = build_url({'mode': 'mdblist.list.build_mdblist_list', 'list_id': list_id, 'list_name': list_name, 'iconImage': 'mdblist', 'name': list_name})
				cm = [('[B]Add to Shortcut Folder[/B]', 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.shortcut_folder_add_known', 'url': url}))]
				listitem = make_listitem()
				listitem.setLabel(display)
				listitem.setArt({'icon': mdblist_icon, 'poster': mdblist_icon, 'thumb': mdblist_icon, 'fanart': fanart, 'banner': fanart})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setPlot(' ')
				listitem.addContextMenuItems(cm)
				yield (url, listitem, True)
			except: pass
	handle, search_title, mdblist_icon, fanart = int(sys.argv[1]), '', kodi_utils.get_icon('mdblist'), kodi_utils.get_addon_fanart()
	build_url, make_listitem = kodi_utils.build_url, kodi_utils.make_listitem
	try:
		search_title = params.get('key_id') or params.get('query')
		lists = mdblist_search_lists(search_title)
		kodi_utils.add_items(handle, list(_builder()))
	except: pass
	kodi_utils.set_content(handle, 'files')
	kodi_utils.set_category(handle, search_title.capitalize())
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main')

def _list_common(params, data, list_type):
	def get_custom_image(list_name, image_type, images):
		try:
			md5_image_name = gen_md5('%s_%s' % (list_name, list_type))
			custom_image = [i for i in images if i.rsplit('_', 1)[0] == md5_image_name][0]
			return os.path.join(profile_path, 'images', 'mdblist_%s_%s' % (list_type, image_type), custom_image)
		except: return ''
	def _process():
		for item in data:
			try:
				cm = []
				cm_append = cm.append
				list_name, list_id, user, slug, item_count = item['name'], item['id'], item['user_name'], item['slug'], item['items']
				if str(list_id) in all_custom_sorts:
					custom_sorts = all_custom_sorts[str(list_id)]
					sort_by, sort_how = custom_sorts['sort_by'], custom_sorts['sort_how']
				else: sort_by, sort_how = 'rank', 'asc'
				custom_poster = get_custom_image(list_name, 'poster', all_posters)
				poster = custom_poster or mdblist_icon
				custom_fanart = get_custom_image(list_name, 'fanart', all_fanart)
				background = custom_fanart or fanart
				mode = 'random.build_mdblist_lists_contents' if random else 'mdblist.list.build_mdblist_list'
				url_params = {'mode': mode, 'list_id': list_id, 'list_name': list_name, 'list_type': list_type, 'iconImage': 'mdblist',
					'name': list_name, 'sort_by': sort_by, 'sort_how': sort_how}
				if random: url_params['random'] = 'true'
				url = build_url(url_params)
				display = '%s [I](x%s)[/I]' % (list_name, str(item_count))
				if list_type == 'my_lists':
					cm_append(('[B]Make New List[/B]', 'RunPlugin(%s)' % build_url({'mode': 'mdblist.make_new_list'})))
					cm_append(('[B]Delete List[/B]', 'RunPlugin(%s)' % build_url({'mode': 'mdblist.delete_list', 'list_id': list_id})))
				cm_append(('[B]Add to Shortcut Folder[/B]', 'RunPlugin(%s)' % build_url({'mode': 'menu_editor.shortcut_folder_add_known', 'url': url})))
				cm_append(('[B]Set Custom Sort[/B]', 'RunPlugin(%s)' % build_url({'mode': 'mdblist.list.list_custom_sort', 'list_id': list_id,
					'sort_by': sort_by, 'sort_how': sort_how})))
				cm_append(('[B]Make Custom Poster[/B]', 'RunPlugin(%s)' % build_url({'mode': 'mdblist.list.make_custom_artwork', 'action': 'make_poster',
					'custom_image': custom_poster, 'list_name': list_name, 'list_type': list_type, 'list_id': list_id})))
				cm_append(('[B]Make Custom Fanart[/B]', 'RunPlugin(%s)' % build_url({'mode': 'mdblist.list.make_custom_artwork', 'action': 'make_fanart',
					'custom_image': custom_fanart, 'list_name': list_name, 'list_type': list_type, 'list_id': list_id})))
				if custom_poster: cm_append(('[B]Delete Custom Poster[/B]', 'RunPlugin(%s)' % build_url({'mode': 'mdblist.list.delete_current_image', 'custom_image': custom_poster})))
				if custom_fanart: cm_append(('[B]Delete Custom Fanart[/B]', 'RunPlugin(%s)' % build_url({'mode': 'mdblist.list.delete_current_image', 'custom_image': custom_fanart})))
				listitem = make_listitem()
				listitem.setLabel(display)
				listitem.setArt({'icon': poster, 'poster': poster, 'thumb': poster, 'fanart': background, 'banner': background})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setPlot(' ')
				listitem.addContextMenuItems(cm)
				yield (url, listitem, True)
			except: pass
	build_url, make_listitem = kodi_utils.build_url, kodi_utils.make_listitem
	mdblist_icon, fanart = kodi_utils.get_icon('mdblist'), kodi_utils.get_addon_fanart()
	profile_path = kodi_utils.addon_profile()
	all_posters = kodi_utils.list_dirs(os.path.join(profile_path, 'images', 'mdblist_%s_poster' % list_type))[1]
	all_fanart = kodi_utils.list_dirs(os.path.join(profile_path, 'images', 'mdblist_%s_fanart' % list_type))[1]
	all_custom_sorts = get_all_lists_custom_sort()
	random, shuffle_lists = params.get('random', 'false') == 'true', params.get('shuffle', 'false') == 'true'
	returning_to_list = False
	if shuffle_lists:
		returning_to_list = 'build_mdblist_lists_contents' in kodi_utils.folder_path()
		if returning_to_list:
			try: data = json.loads(kodi_utils.get_property('fenlight.mdblist.lists.order'))
			except: pass
		else:
			shuffle(data)
			kodi_utils.set_property('fenlight.mdblist.lists.order', json.dumps(data))
	else:
		kodi_utils.clear_property('fenlight.mdblist.lists.order')
		data.sort(key=lambda k: k['name'])
	result = list(_process())
	if shuffle_lists and not returning_to_list: kodi_utils.focus_index(0)
	return result

def get_mdblist_lists(params):
	handle = int(sys.argv[1])
	try:
		data = mdblist_get_my_lists()
		result = _list_common(params, data, 'my_lists')
		kodi_utils.add_items(handle, result)
	except: pass
	kodi_utils.set_content(handle, 'files')
	kodi_utils.set_category(handle, params.get('category_name', 'My Lists'))
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main')

def get_mdblist_popular_lists(params):
	handle = int(sys.argv[1])
	try:
		data = mdblist_get_popular_lists()
		result = _list_common(params, data, 'popular_lists')
		kodi_utils.add_items(handle, result)
	except: pass
	kodi_utils.set_content(handle, 'files')
	kodi_utils.set_category(handle, params.get('category_name', 'Popular Lists'))
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main')

def make_new_list(params):
	list_title = kodi_utils.kodi_dialog().input('')
	if not list_title: return
	mdblist_make_new_list(list_title, private=False)
	kodi_utils.kodi_refresh()

def delete_list(params):
	list_id = params['list_id']
	if not kodi_utils.confirm_dialog(): return
	mdblist_delete_list(list_id)
	kodi_utils.kodi_refresh()

def build_mdblist_list(params):
	def _process(function, _list, _type):
		if not _list['list']: return
		item_list_extend(function(_list).worker())
	def _paginate_list(data, page_no, paginate_start):
		if use_result: return data, 1, paginate_start
		if paginate_enabled:
			limit = page_limit(is_external)
			data, total_pages = paginate_list(data, page_no, limit, paginate_start)
			if is_external: paginate_start = limit
		else: total_pages = 1
		return data, total_pages, paginate_start
	handle, is_external, list_name, content = int(sys.argv[1]), kodi_utils.external(), params.get('list_name'), 'movies'
	hide_next_page = is_external and widget_hide_next_page()
	try:
		threads, item_list = [], []
		item_list_extend = item_list.extend
		paginate_enabled = paginate(is_external)
		use_result = 'result' in params
		page_no, paginate_start = int(params.get('new_page', '1')), int(params.get('paginate_start', '0'))
		if page_no == 1 and not is_external: kodi_utils.set_property('fenlight.exit_params', kodi_utils.folder_path())
		if use_result: result = params.get('result', [])
		else:
			list_id, sort_by, sort_how = params.get('list_id'), params.get('sort_by', 'rank'), params.get('sort_how', 'asc')
			result = mdblist_list_contents(list_id=list_id, sort_by=sort_by, sort_how=sort_how)
		process_list, total_pages, paginate_start = _paginate_list(result, page_no, paginate_start)
		all_movies = [i for i in process_list if i['type'] == 'movie']
		all_tvshows = [i for i in process_list if i['type'] == 'show']
		movie_list = {'list': [(i['order'], i['media_ids']) for i in all_movies], 'id_type': 'trakt_dict', 'custom_order': 'true'}
		tvshow_list = {'list': [(i['order'], i['media_ids']) for i in all_tvshows], 'id_type': 'trakt_dict', 'custom_order': 'true'}
		content = max([('movies', len(all_movies)), ('tvshows', len(all_tvshows))], key=lambda k: k[1])[0]
		for item in ((Movies, movie_list, 'movies'), (TVShows, tvshow_list, 'tvshows')):
			threaded_object = Thread(target=_process, args=item)
			threaded_object.start()
			threads.append(threaded_object)
		[i.join() for i in threads]
		item_list.sort(key=lambda k: k[1])
		if use_result: return content, [i[0] for i in item_list]
		list_id = params.get('list_id')
		new_params = {'mode': 'mdblist.list.build_mdblist_list', 'list_id': list_id, 'list_name': list_name, 'paginate_start': paginate_start,
						'sort_by': params.get('sort_by', 'rank'), 'sort_how': params.get('sort_how', 'asc')}
		kodi_utils.add_items(handle, [i[0] for i in item_list])
		if total_pages > 2 and jump_to_enabled() and not is_external:
				kodi_utils.add_dir(handle, {'mode': 'navigate_to_page_choice', 'current_page': page_no, 'total_pages': total_pages, 'url_params': json.dumps(new_params)},
											'Jump To...', 'item_jump', kodi_utils.get_icon('item_jump_landscape'), isFolder=False)
		if total_pages > page_no and not hide_next_page:
			new_page = str(page_no + 1)
			new_params['new_page'] = new_page
			kodi_utils.add_dir(handle, new_params,  'Next Page (%s) >>' % new_page, 'nextpage', kodi_utils.get_icon('nextpage_landscape'))
	except: pass
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, list_name)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	if not is_external:
		if params.get('refreshed') == 'true': kodi_utils.sleep(1000)
		kodi_utils.set_view_mode('view.%s' % content, content, is_external)

def make_custom_artwork(params):
	action, list_name, list_type, list_id = params['action'], params['list_name'], params['list_type'], params['list_id']
	custom_image = params['custom_image']
	art_type, image_type = ('Posters', 'poster') if action == 'make_poster' else ('Fanart', 'fanart')
	shuffle_art = kodi_utils.confirm_dialog(
		heading='MDBList List', text='Use [B]4 Random[/B] %s from List?[CR]OR[CR]Use [B]First 4[/B] %s from List?' % (art_type, art_type),
		ok_label='4 Random', cancel_label='First 4')
	if shuffle_art == None: return
	mdblist_image_maker(list_name, list_type, list_id, image_type, custom_image, shuffle_art)
	kodi_utils.kodi_refresh()

def mdblist_image_maker(list_name, list_type, list_id, image_type, custom_image, shuffle_sort_order):
	from random import shuffle as _shuffle
	from caches.trakt_cache import get_list_custom_sort
	from modules import metadata
	from modules.utils import make_image, get_datetime, get_current_timestamp
	from modules.settings import tmdb_api_key, mpaa_region
	kodi_utils.show_busy_dialog()
	sort_info = get_list_custom_sort(list_id)
	sort_by, sort_how = sort_info['sort_by'], sort_info['sort_how']
	content = mdblist_list_contents(list_id=list_id, sort_by=sort_by, sort_how=sort_how)
	if shuffle_sort_order: _shuffle(content)
	images = []
	api_key, mpaa, current_time, current_timestamp = tmdb_api_key(), mpaa_region(), get_datetime(), get_current_timestamp()
	for item in content:
		try:
			tmdb_id = item['media_ids']['tmdb']
			if not tmdb_id: continue
			function = metadata.movie_meta if item['type'] == 'movie' else metadata.tvshow_meta
			meta = function('tmdb_id', tmdb_id, api_key, mpaa, current_time, current_timestamp)
			if meta.get(image_type): images.append(meta[image_type])
			if len(images) == 4: break
		except: pass
	final_image = make_image('mdblist_%s' % list_type, image_type, '%s_%s' % (list_name, list_type), images, custom_image)
	kodi_utils.hide_busy_dialog()
	return final_image

def delete_current_image(params):
	custom_image = params['custom_image']
	os.remove(custom_image)
	kodi_utils.sleep(1000)
	success = not kodi_utils.path_exists(custom_image)
	if success: kodi_utils.kodi_refresh()
	else: kodi_utils.notification('Error Deleting Image')

def list_custom_sort(params):
	# Mire Sirens: sort options narrowed to a practical subset of MDBList's much longer
	# `sort` enum (rank/score/usort/score_average/released/releasedigital/imdbrating/
	# imdbvotes/last_air_date/imdbpopular/tmdbpopular/rogerebert/rtomatoes/rtaudience/
	# metacritic/myanimelist/letterrating/lettervotes/budget/revenue/runtime/title/
	# sort_title/added/random) - the full list would make a clunky selection dialog.
	list_id, current_by, current_how = params['list_id'], params['sort_by'], params['sort_how']
	choices = [('rank', 'Default From List%s'), ('added', 'Date Added%s'), ('title', 'Title%s'), ('released', 'Date Released%s'), ('runtime', 'Runtime%s'),
	('tmdbpopular', 'Popularity%s'), ('score', 'MDBList Score%s'), ('imdbvotes', 'Votes%s'), ('random', 'Random%s')]
	choices = [(i[0], i[1] % ('   [B][COLOR green][CURRENT][/COLOR][/B]' if i[0] == current_by else '')) for i in choices]
	list_items = [{'line1': item[1], 'line2': ''} for item in choices]
	kwargs = {'items': json.dumps(list_items), 'heading': 'MDBList List Custom Sort By', 'narrow_window': 'true'}
	sort_by = kodi_utils.select_dialog([i[0] for i in choices], **kwargs)
	if sort_by == None: return
	if sort_by == 'rank':
		success = delete_list_custom_sort(list_id)
		if success:
			kodi_utils.ok_dialog('MDBList List Custom Sort', 'Success')
			kodi_utils.kodi_refresh()
		else: kodi_utils.ok_dialog('MDBList List Custom Sort', 'An Error Occured')
		return
	else:
		choices = [('asc', 'Ascending%s'), ('desc', 'Descending%s')]
		choices = [(i[0], i[1] % ('   [B][COLOR green][CURRENT][/COLOR][/B]' if i[0] == current_how else '')) for i in choices]
		list_items = [{'line1': item[1], 'line2': ''} for item in choices]
		kwargs = {'items': json.dumps(list_items), 'heading': 'MDBList List Custom Sort How', 'narrow_window': 'true'}
		sort_how = kodi_utils.select_dialog([i[0] for i in choices], **kwargs)
		if sort_how == None: return
	success = set_list_custom_sort(list_id, {'list_id': list_id, 'sort_by': sort_by, 'sort_how': sort_how})
	if success:
		kodi_utils.ok_dialog('MDBList List Custom Sort', 'Success')
		kodi_utils.kodi_refresh()
	else: kodi_utils.ok_dialog('MDBList List Custom Sort', 'An Error Occured')
