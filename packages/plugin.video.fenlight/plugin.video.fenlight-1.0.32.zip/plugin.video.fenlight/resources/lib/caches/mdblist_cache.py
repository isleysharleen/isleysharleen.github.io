# -*- coding: utf-8 -*-
# Mire Sirens: MDBList-branded cache, mirroring trakt_cache.py's interface.
#
# NOTE: this intentionally reuses the existing 'trakt_db' physical SQLite database
# (traktcache.db / table trakt_data) as generic key-value storage, rather than adding a
# new database. That table was always a generic (id, data) cache — nothing about its
# physical name is user-facing, and repointing it here avoids a database migration and a
# fresh empty cache with no functional upside. If you'd rather have a fully separate
# mdblistcache.db, add an 'mdblist_db' entry to base_cache.py's table_creators()/
# locations()/check_databases_integrity() and swap connect_database('trakt_db') below.
from caches.base_cache import connect_database, _with_lock_retry, dumps, loads
from caches.settings_cache import get_setting

def _get_timestamp(offset=0):
	from caches.base_cache import get_timestamp
	return get_timestamp(offset)

class MDBListCache:
	def get(self, string):
		def _action():
			dbcon = connect_database('trakt_db')
			cache_data = dbcon.execute('SELECT data FROM trakt_data WHERE id = ?', (string,)).fetchone()
			if cache_data:
				parsed = loads(cache_data[0])
				# New format: (expires_at, value) - expires_at is None for entries meant to
				# persist indefinitely (e.g. the last-error log), or a real timestamp for
				# everything else. Old pre-TTL entries were a bare value with no wrapper -
				# treated as an automatic miss so they get re-fetched once and upgraded to
				# this format, rather than needing a separate migration step. json round-trips
				# this as a 2-item list rather than a tuple - accept either.
				if isinstance(parsed, (list, tuple)) and len(parsed) == 2 and (parsed[0] is None or isinstance(parsed[0], (int, float))):
					expires_at, value = parsed
					if expires_at is None or _get_timestamp(0) < expires_at: return value
			return None
		return _with_lock_retry(_action)

	def set(self, string, data, expiration=1):
		expires_at = None if expiration is None else _get_timestamp(expiration)
		def _action():
			dbcon = connect_database('trakt_db')
			dbcon.execute('INSERT OR REPLACE INTO trakt_data (id, data) VALUES (?, ?)', (string, dumps((expires_at, data))))
			return True
		return _with_lock_retry(_action)

	def delete(self, string):
		def _action():
			dbcon = connect_database('trakt_db')
			dbcon.execute('DELETE FROM trakt_data WHERE id = ?', (string,))
			return True
		return _with_lock_retry(_action)

mdblist_cache = MDBListCache()

def cache_mdblist_object(function, string, params, expiration=1):
	# Simple pass-through cache: compute once, store, reuse until explicitly invalidated
	# by the write-path calls (add_to_collection/remove_from_collection/hide_unhide_progress_items),
	# OR until `expiration` hours have passed (see MDBListCache.set/get above) - added
	# after a report of shows fully watched on mdblist.com directly (not through this
	# addon) still showing as in-progress here, sometimes well after the fact: every one
	# of these caches previously had NO time-based expiration at all, only the explicit
	# per-action invalidations above, so a change made anywhere other than this addon
	# (the website, Plex, another device) could sit unreflected indefinitely. Default of
	# 1 hour balances staying reasonably current against not re-hitting MDBList's API
	# (which is itself rate-limited - see call_mdblist's retry logic) too often.
	#
	# BUGFIX: previously did `result = function(params) or []` and cached that
	# unconditionally — meaning ANY failed/empty call (dropped connection, bad API key,
	# a curated list's id not yet resolving, a first-run hiccup, etc.) got written to the
	# cache as [] and stayed there PERMANENTLY, since most callers here (Collection,
	# Watchlist, curated Trending/Box Office lists, My Lists...) have no periodic
	# expiration — the `expiration` param above is accepted but was never actually used
	# anywhere in this function. Reported symptom: Collection and several curated lists
	# showing permanently blank. Fixed by only writing to cache on a genuinely non-empty
	# result; a failed/empty call now returns [] to the caller (same as before) but isn't
	# persisted, so the next request retries instead of repeating the same blank forever.
	# NOTE: this means a list that is legitimately and correctly empty (e.g. an empty
	# Collection) will re-fetch on every call instead of being cached — a minor, safe
	# tradeoff in favor of never getting stuck showing a wrong blank.
	cached = mdblist_cache.get(string)
	if cached is not None: return cached
	result = function(params)
	if result: mdblist_cache.set(string, result, expiration)
	return result or []
