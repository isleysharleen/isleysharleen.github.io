# -*- coding: utf-8 -*-
# Mire Sirens: MDBList personal-tracking API.
#
# This module is the MDBList equivalent of the tracking functions that used to live in
# trakt_api.py (trakt_watched_status_mark, trakt_progress, trakt_get_hidden_items,
# hide_unhide_progress_items, trakt_official_status, add/remove collection). Most discovery
# features (search/recommendations) are NOT handled here — those run on tmdb_api.py.
#
# EXCEPTION: Trending/Most Watched (movies + TV) and Top 10 Box Office (movies only) ARE
# handled here — see mdblist_movies_trending/mdblist_movies_most_watched/
# mdblist_movies_top10_boxoffice/mdblist_tv_trending/mdblist_tv_most_watched below.
# MDBList maintains public, auto-updating lists (several different curator accounts, not
# just one) that mirror these exact Trakt stats — confirmed via mdblist's own docs at
# docs.mdblist.com/docs/popular_lists and live-Browse of mdblist.com/toplists (see
# CURATED_LIST_CANDIDATES further down for the actual (user, slug) pairs found). This was
# NOT tested live against a real API key (sandbox can't reach api.mdblist.com) — verify
# the first real call and report back any errors.
# Trending Recent and Most Favorited still have no MDBList equivalent found (Trakt-only,
# not yet decided whether to drop from the menu).
#
# NOTE ON WATCHLIST: confirmed against the community MDBList Kodi Scrobbler's own working
# code — MDBList DOES have a dedicated watchlist endpoint (GET /watchlist/items/<type> to
# fetch, POST /watchlist/items/add and /watchlist/items/remove to modify). The earlier
# assumption that watchlist was just a regular list was wrong. Implemented below.
#
# NOTE ON SCROBBLING: Mire Sirens' own player.py already drives watched-marking and
# progress itself (it polls playback and calls into watched_status.py directly), so
# automatic scrobbling doesn't depend on a separate companion addon the way script.trakt
# used to. mdblist_official_status()/SCROBBLER_ADDON_ID deferral has been removed
# accordingly. (Rating prompt/save was considered but not implemented — declined.)
import requests
import json
from caches import mdblist_cache
from caches.settings_cache import get_setting, set_setting
from modules import kodi_utils, settings
from modules.kodi_utils import confirm_dialog, kodi_dialog, ok_dialog, notification, show_text
from modules.utils import sort_for_article, get_datetime, get_current_timestamp, TaskPool

API_ENDPOINT = 'https://api.mdblist.com/%s'

def no_api_key():
	notification('Please set a valid MDBList API Key')
	return None

def mdblist_api_key():
	# BYO key, same pattern as the TMDb v4 token: read from settings, prompt once on first use.
	key = settings.mdblist_api_key()
	if key: return key
	key = _prompt_for_api_key()
	if key: set_setting('mdblist_api_key', key)
	return key

def _prompt_for_api_key():
	intro = ('Mire Sirens needs your MDBList API key to track watched status, progress, '
			'and collection.[CR][CR]'
			'1. Sign in at https://mdblist.com[CR]'
			'2. Go to your Account/Preferences page[CR]'
			'3. Copy your API Key[CR][CR]'
			'Continue to enter the key now?')
	if not confirm_dialog(heading='MDBList API Key Required', text=intro, ok_label='Enter Key', cancel_label='Cancel'):
		notification('MDBList tracking unavailable until a key is entered')
		return None
	key = kodi_dialog().input('Paste your MDBList API Key')
	if not key:
		notification('No key entered. MDBList tracking unavailable.')
		return None
	return key

def _record_mdblist_error(path, method, detail):
	# Diagnostic aid: persists the most recent MDBList API failure so it can be viewed
	# on-screen via a menu item, for situations where the user can't get to kodi.log.
	try: mdblist_cache.mdblist_cache.set('mdblist_last_error', '[%s] %s\n%s' % (method.upper(), path, detail)[:4000], expiration=None)
	except: pass

def call_mdblist(path, params=None, data=None, method='get'):
	# BUGFIX: MDBList's own Cloudflare protection can 429 a request during a burst of
	# calls (confirmed via "Show Last MDBList Error" showing a real 429/Cloudflare
	# "Access denied" response on sync/playback) - previously treated exactly like any
	# other failure with zero retry, same class of issue already fixed on the TMDB side
	# (see get_tmdb() in tmdb_api.py). Now retries a 429 a few times with backoff before
	# giving up and recording it as a real failure.
	API_KEY = mdblist_api_key()
	if not API_KEY: return no_api_key()
	params = dict(params or {})
	params['apikey'] = API_KEY
	headers = {'Content-Type': 'application/json'}
	resp = None
	import time
	for attempt in range(4):
		try:
			if method == 'post': resp = requests.post(API_ENDPOINT % path, params=params, json=data, headers=headers, timeout=15)
			elif method == 'delete': resp = requests.delete(API_ENDPOINT % path, params=params, json=data, headers=headers, timeout=15)
			else: resp = requests.get(API_ENDPOINT % path, params=params, headers=headers, timeout=15)
			if resp.status_code == 429 and attempt < 3:
				try: wait = float(resp.headers.get('Retry-After', 1))
				except: wait = 1
				time.sleep(min(wait, 5) + attempt * 0.5)
				continue
			resp.raise_for_status()
			break
		except Exception as e:
			if resp is not None and resp.status_code == 429 and attempt < 3: continue
			detail = str(e)
			if resp is not None:
				try: detail = 'HTTP %s: %s' % (resp.status_code, resp.text[:500])
				except: pass
			_record_mdblist_error(path, method, detail)
			kodi_utils.logger('MDBList Error', detail)
			return None
	try: return resp.json()
	except Exception as e:
		_record_mdblist_error(path, method, 'JSON parse failed (%s). Raw response: %s' % (str(e), (resp.text or '')[:500]))
		return None

def mdblist_show_last_error():
	# Menu-triggered diagnostic: shows the most recent MDBList API failure, for when the
	# user can't pull kodi.log directly off their device. Uses show_text (the same
	# scrollable/copyable text viewer as the Kodi log viewer) instead of ok_dialog, since
	# ok_dialog's small fixed window doesn't scroll or allow copying longer text.
	last = mdblist_cache.mdblist_cache.get('mdblist_last_error')
	show_text(heading='MDBList Last Error', text=last or 'No MDBList API errors recorded yet.')

def mdblist_diagnose_curated_lists():
	# Menu-triggered diagnostic: for each curated list, shows which resolution path
	# actually succeeded (official /lists/official name match, a guessed third-party
	# candidate, or the generic name-search fallback), what it resolved to, and how many
	# items came back on page 1 — built while chasing a persistent "Top 10 Box Office only
	# shows 2" report that survived a genuine, verified-non-empty cache clear, meaning the
	# resolution itself (not caching) is where the problem actually is. This makes that
	# directly visible instead of continuing to guess blind.
	lines = []
	for list_key in ('movies_trending', 'movies_most_watched', 'movies_top10_boxoffice', 'tv_trending', 'tv_most_watched', 'anime_trending'):
		try:
			official_slug = _official_list_slug(list_key)
			if official_slug:
				method, ref = 'official', official_slug
			else:
				candidate_id, candidate_ref = None, None
				for user, slug in CURATED_LIST_CANDIDATES.get(list_key, ()):
					by_slug = _user_list_slugs(user)
					if slug in by_slug:
						candidate_id = by_slug[slug]
						candidate_ref = '%s/%s (id %s)' % (user, slug, candidate_id)
						break
				if candidate_id:
					method, ref = 'guessed candidate', candidate_ref
				else:
					search_id = _curated_list_id_by_search(list_key)
					if search_id: method, ref = 'generic search', 'id %s' % search_id
					else: method, ref = 'NONE RESOLVED', '-'
			items = _curated_list_items(list_key, 1)
			lines.append('%s: %s -> %s (%s items on page 1)' % (list_key, method, ref, len(items or [])))
		except Exception as e:
			lines.append('%s: ERROR - %s' % (list_key, str(e)))
	show_text(heading='MDBList Curated List Diagnostics', text='\n'.join(lines))

def mdblist_diagnose_calendar():
	# Menu-triggered diagnostic (mirrors mdblist_diagnose_curated_lists): walks the exact
	# same Watchlist+Collection -> TMDB season/episode logic as mdblist_get_my_calendar()
	# and reports, per show, why it did or didn't produce a Calendar entry - so this can
	# be checked without needing kodi.log access. Read-only: does not touch the Calendar
	# cache, just recomputes the same thing for reporting.
	from modules.metadata import tvshow_meta, episodes_meta
	current_date = get_datetime()
	start_str, finish_str = _mdblist_calendar_days(False, current_date)
	api_key, mpaa_region_value = settings.tmdb_api_key(), settings.mpaa_region()
	watchlist = mdblist_watchlist_fetch('tvshow')
	collection = mdblist_fetch_collection('tvshow')
	seen_shows, shows = set(), []
	for item in (watchlist or []) + (collection or []):
		media_ids = item.get('media_ids') or {}
		dedup_key = media_ids.get('tmdb') or media_ids.get('imdb') or media_ids.get('tvdb')
		if not dedup_key or dedup_key in seen_shows: continue
		seen_shows.add(dedup_key)
		shows.append(item)
	lines = ['Window: %s to %s (from your Calendar previous/future day settings)' % (start_str, finish_str), '']
	for item in shows:
		title = item.get('title', '?')
		try:
			media_ids = item.get('media_ids') or {}
			if not media_ids.get('tmdb') and not media_ids.get('imdb') and not media_ids.get('tvdb'):
				lines.append('%s: NO tmdb/imdb/tvdb id at all (media_ids=%s)' % (title, media_ids)); continue
			meta = tvshow_meta('trakt_dict', media_ids, api_key, mpaa_region_value, current_date)
			if not meta or meta.get('blank_entry'):
				lines.append('%s: TMDB meta lookup failed/blank (media_ids=%s)' % (title, media_ids)); continue
			extra_info = meta.get('extra_info') or {}
			next_ep, last_ep = extra_info.get('next_episode_to_air'), extra_info.get('last_episode_to_air')
			seasons = set()
			if next_ep and next_ep.get('season_number') is not None: seasons.add(int(next_ep['season_number']))
			if last_ep and last_ep.get('season_number') is not None: seasons.add(int(last_ep['season_number']))
			if not seasons:
				lines.append('%s: no season resolved (status=%s, next_ep=%s, last_ep=%s)' % (title, meta.get('status'), next_ep, last_ep)); continue
			show_title = meta.get('title', title)
			ident = 'raw_ids=%s -> resolved tmdb_id=%s, status=%s, total_seasons=%s' % (media_ids, meta.get('tmdb_id'), meta.get('status'), meta.get('total_seasons'))
			found, detail = [], []
			for season in seasons:
				try: episodes = episodes_meta(season, meta)
				except Exception as e:
					detail.append('season %s errored: %s' % (season, str(e))); continue
				in_window, nearest_upcoming = 0, None
				for ep in episodes or []:
					premiered = ep.get('premiered')
					if premiered and premiered > finish_str and (nearest_upcoming is None or premiered < nearest_upcoming):
						nearest_upcoming = premiered
					if not premiered or not (start_str <= premiered <= finish_str): continue
					in_window += 1
					found.append('S%sE%s (%s)' % (ep.get('season'), ep.get('episode'), premiered))
				extra = ' next upcoming outside window: %s' % nearest_upcoming if nearest_upcoming else ''
				detail.append('season %s: %s episode(s) total, %s in window.%s' % (season, len(episodes or []), in_window, extra))
			if found: lines.append('%s (%s): IN CALENDAR -> %s | %s' % (show_title, ident, ', '.join(found), '; '.join(detail)))
			else: lines.append('%s (%s): NOT in Calendar. %s' % (show_title, ident, '; '.join(detail)))
		except Exception as e:
			lines.append('%s: ERROR - %s' % (title, str(e)))
	report = '\n'.join(lines)
	export_path = None
	try:
		folder = kodi_utils.translate_path('special://profile/addon_data/plugin.video.fenlight/')
		if not kodi_utils.path_exists(folder): kodi_utils.make_directories(folder)
		export_path = folder + 'calendar_diagnostics.txt'
		f = kodi_utils.open_file(export_path, 'w')
		f.write(report)
		f.close()
	except Exception as e:
		kodi_utils.logger('Mire Sirens Calendar Diagnostics export failed', str(e))
		export_path = None
	if export_path:
		ok_dialog('Calendar Diagnostics Exported', 'Full report saved to:\n%s\n\nYou can open that file directly (e.g. in Notepad) or share it - no copy/paste needed.' % export_path)
	show_text(heading='MDBList Calendar Diagnostics', text=report)

def _ids_payload(media_id, tvdb_id=0, key='tmdb'):
	ids = {key: media_id}
	return ids

def mdblist_watched_status_mark(action, media, media_id, tvdb_id=0, season=None, episode=None, key='tmdb'):
	# Mirrors trakt_watched_status_mark's signature/shape so call sites in watched_status.py
	# barely change. add -> POST /sync/watched, remove -> DELETE /sync/watched.
	method = 'post' if action == 'mark_as_watched' else 'delete'
	if media == 'movies':
		data = {'movies': [{'ids': _ids_payload(media_id, tvdb_id, key)}]}
	else:
		if media == 'episode':
			data = {'shows': [{'ids': _ids_payload(media_id, tvdb_id, key),
								'seasons': [{'number': int(season), 'episodes': [{'number': int(episode)}]}]}]}
		elif media == 'shows':
			data = {'shows': [{'ids': _ids_payload(media_id, tvdb_id, key)}]}
		else:
			data = {'shows': [{'ids': _ids_payload(media_id, tvdb_id, key), 'seasons': [{'number': int(season)}]}]}
	result = call_mdblist('sync/watched', data=data, method=method)
	if result is None:
		if media != 'movies' and tvdb_id != 0 and key != 'tvdb':
			return mdblist_watched_status_mark(action, media, tvdb_id, 0, season, episode, 'tvdb')
		return False
	mdblist_cache.mdblist_cache.delete('mdblist_watched_history')
	return True

def mdblist_progress(action, media, media_id, percent, season=None, episode=None, resume_id=None, refresh_mdblist=False):
	# Mirrors trakt_progress(). set_progress -> POST /sync/playback (resumable across devices),
	# clear_progress -> DELETE /sync/playback for the same item.
	if media in ('movie', 'movies'):
		item = {'movie': {'ids': {'tmdb': media_id}}}
	else:
		item = {'show': {'ids': {'tmdb': media_id}}, 'episode': {'season': int(season), 'number': int(episode)}}
	if action == 'clear_progress':
		call_mdblist('sync/playback', data=item, method='delete')
	else:
		data = dict(item, progress=float(percent))
		call_mdblist('sync/playback', data=data, method='post')
	mdblist_cache.mdblist_cache.delete('mdblist_playback_bookmarks')
	if refresh_mdblist: mdblist_sync_activities()

def mdblist_get_hidden_items(list_type='dropped'):
	def _get_ids(item):
		try: results_append(int(item['show']['ids']['tmdb']))
		except: pass
	def _process(dummy):
		data = call_mdblist('sync/dropped', method='get') or []
		# BUGFIX: /sync/dropped is documented as BETA by MDBList and this was only ever
		# assumed (never live-confirmed) to return a flat list like /sync/playback does.
		# Tolerate a dict-wrapped shape too (e.g. {'shows': [...]}) so this doesn't
		# silently parse to zero results if the real response is shaped that way.
		if isinstance(data, dict): data = data.get('shows') or data.get('items') or data.get('data') or []
		threads = TaskPool().tasks(_get_ids, data, min(len(data), settings.max_threads()))
		[i.join() for i in threads]
		return results
	results = []
	results_append = results.append
	string = 'mdblist_hidden_items_%s' % list_type
	return mdblist_cache.cache_mdblist_object(_process, string, 'dummy')

def hide_unhide_progress_items(params):
	# Mirrors trakt_api.hide_unhide_progress_items(). 'drop' hides a show from in-progress,
	# 'undrop' restores it. Only shows are supported by MDBList's /sync/dropped, same as Trakt.
	action, media_id = params['action'], params['media_id']
	data = {'shows': [{'ids': {'tmdb': media_id}}]}
	method = 'post' if action == 'drop' else 'delete'
	call_mdblist('sync/dropped', data=data, method=method)
	mdblist_cache.mdblist_cache.delete('mdblist_hidden_items_dropped')

# BUGFIX (blank/stale Collection): callers pass inconsistent media_type strings here
# ('movies' from movies.py, 'shows' from tvshows.py, occasionally 'movie'/'tvshow'
# elsewhere) which used to go straight into the cache key (mdblist_collection_movies,
# mdblist_collection_shows, ...). But add_to_collection/remove_from_collection below only
# ever invalidated the singular forms (mdblist_collection_movie, mdblist_collection_show)
# — those never matched, so every write-time cache invalidation was silently a no-op and
# Collection could never actually refresh after adding/removing something. Fixed by
# normalizing to the same singular key everywhere it's used, both for reading and for the
# invalidation calls below.
def _collection_key(media_type):
	return 'movie' if media_type in ('movie', 'movies') else 'show'

def mdblist_fetch_collection(media_type):
	# BUGFIX (the real root cause of blank Collection, confirmed against Umbrella's actual
	# published, working MDBList integration — see resources/lib/modules/mdblist.py's
	# get_user_collection): sync/collection requires a 'mediatype' query param ('movie' or
	# 'episode' — NOT 'show'; MDBList tracks TV collection at the episode level, not the
	# show level) and returns a cursor-paginated dict ({'movies': [...], 'pagination': {...}}
	# or {'episodes': [...], 'pagination': {...}}) — not the flat Trakt-shaped list this
	# code used to assume. Each raw item is nested one level further too: a movie item's
	# ids/title live under item['movie'], an episode item's under item['episode']['show'].
	# Without the mediatype param the call was very likely erroring or returning something
	# this old code couldn't parse at all, silently swallowed into an empty list — this
	# fully explains the blank Collection independent of the separate caching bugs already
	# fixed above (those were real too, just not the whole story).
	key = _collection_key(media_type)
	mdblist_mediatype = 'movie' if key == 'movie' else 'episode'
	def _process(dummy):
		cursor, raw = None, []
		while True:
			params = {'mediatype': mdblist_mediatype, 'limit': 1000}
			if cursor: params['cursor'] = cursor
			data = call_mdblist('sync/collection', params=params, method='get')
			if not data: break
			raw.extend(data.get('movies') or data.get('episodes') or [])
			cursor = (data.get('pagination') or {}).get('next_cursor')
			if not cursor: break
		results, seen = [], set()
		for i in raw:
			# Movies: ids/title nested under item['movie']. TV: MDBList returns one row
			# per collected episode, so dedupe down to one entry per show via item['episode']['show'].
			nested = i.get('movie') if key == 'movie' else (i.get('episode') or {}).get('show')
			nested = nested or {}
			ids = nested.get('ids') or {}
			dedup_key = ids.get('tmdb') or ids.get('imdb')
			if not dedup_key or dedup_key in seen: continue
			seen.add(dedup_key)
			results.append({'media_ids': {'tmdb': ids.get('tmdb', ''), 'imdb': ids.get('imdb', ''), 'tvdb': ids.get('tvdb', '')},
							'title': nested.get('title', ''), 'collected_at': i.get('collected_at')})
		return results
	string = 'mdblist_collection_%s' % key
	return mdblist_cache.cache_mdblist_object(_process, string, 'dummy')

def mdblist_collection(media_type, dummy_arg):
	data = mdblist_fetch_collection(media_type)
	sort_order = settings.lists_sort_order('collection')
	if sort_order == 0: data = sort_for_article(data, 'title', settings.ignore_articles())
	else: data.sort(key=lambda k: k.get('collected_at') or '', reverse=True)
	return data

def mdblist_collection_lists(media_type, list_type=None):
	# Mirrors trakt_collection_lists' shape/call signature so the 'trakt_personal'-style
	# dispatch bucket in movies.py/tvshows.py and random_lists.py's Random Lists screen
	# barely change. list_type='recent' -> sorted+truncated to 20 (for "Recently Added").
	data = mdblist_fetch_collection(media_type)
	if list_type == 'recent':
		data.sort(key=lambda k: k.get('collected_at') or '', reverse=True)
		data = data[:20]
	return data

def add_to_collection(data):
	result = call_mdblist('sync/collection', data=data, method='post')
	mdblist_cache.mdblist_cache.delete('mdblist_collection_movie')
	mdblist_cache.mdblist_cache.delete('mdblist_collection_show')
	if result is None: return notification('Error', 3000)
	return notification('Success', 3000)

def remove_from_collection(data):
	# BUGFIX: was calling DELETE on sync/collection. Confirmed against Umbrella's working
	# integration that MDBList actually uses a dedicated POST /sync/collection/remove
	# sub-path instead (same add/remove-subpath convention already used correctly for
	# Watchlist's /watchlist/items/add and /watchlist/items/remove).
	result = call_mdblist('sync/collection/remove', data=data, method='post')
	mdblist_cache.mdblist_cache.delete('mdblist_collection_movie')
	mdblist_cache.mdblist_cache.delete('mdblist_collection_show')
	if result is None: return notification('Error', 3000)
	notification('Success', 3000)
	if kodi_utils.path_check('mdblist_collection') or kodi_utils.external(): kodi_utils.kodi_refresh()
	return result

def _watchlist_key(media_type):
	return 'movie' if media_type in ('movie', 'movies') else 'show'

def mdblist_watchlist_fetch(media_type):
	# BUGFIX: same cache-key mismatch as mdblist_fetch_collection had (see its comment) —
	# this used to cache under the raw, inconsistent media_type string ('movies'/'shows')
	# while clear_mdblist_watchlist_cache() below invalidated the normalized singular form
	# ('movie'/'show'). They never matched, so Watchlist could never actually refresh after
	# an add/remove either. Normalized to the same key both places.
	key = _watchlist_key(media_type)
	def _process(dummy):
		endpoint = 'watchlist/items/%s' % key
		cursor, results = None, []
		while True:
			params = {'limit': 100}
			if cursor: params['cursor'] = cursor
			data = call_mdblist(endpoint, params=params, method='get')
			if not data: break
			items = data if isinstance(data, list) else (data.get('movies') or data.get('shows') or [])
			results.extend(items)
			pagination = data.get('pagination', {}) if isinstance(data, dict) else {}
			cursor = pagination.get('next_cursor')
			if not cursor: break
		return [{'media_ids': {'tmdb': i.get('ids', {}).get('tmdb', ''), 'imdb': i.get('ids', {}).get('imdb', ''), 'tvdb': i.get('ids', {}).get('tvdb', '')},
				'title': i.get('title', ''), 'listed_at': i.get('watchlisted_at') or i.get('listed_at')} for i in results]
	string = 'mdblist_watchlist_%s' % key
	return mdblist_cache.cache_mdblist_object(_process, string, 'dummy')

def mdblist_watchlist(media_type, dummy_arg):
	data = mdblist_watchlist_fetch(media_type)
	sort_order = settings.lists_sort_order('watchlist')
	if sort_order == 0: data = sort_for_article(data, 'title', settings.ignore_articles())
	else: data.sort(key=lambda k: k.get('listed_at') or '', reverse=True)
	return data

def mdblist_watchlist_lists(media_type, list_type=None):
	# Mirrors trakt_watchlist_lists (see mdblist_collection_lists above for why).
	data = mdblist_watchlist_fetch(media_type)
	if list_type == 'recent':
		data.sort(key=lambda k: k.get('listed_at') or '', reverse=True)
		data = data[:20]
	return data

def clear_mdblist_watchlist_cache(media_type):
	mdblist_cache.mdblist_cache.delete('mdblist_watchlist_%s' % _watchlist_key(media_type))

def _mdblist_calendar_days(recently_aired, current_date):
	# Mirrors trakt_calendar_days(). recently_aired uses a fixed 14-day lookback (same as
	# Trakt's own behaviour); the main calendar uses the user-configurable previous/future
	# day settings (renamed from trakt.calendar_* to calendar.* now that Trakt is gone).
	from datetime import timedelta
	if recently_aired: start, finish = current_date - timedelta(days=14), current_date
	else:
		start = current_date - timedelta(days=settings.calendar_previous_days())
		finish = current_date + timedelta(days=settings.calendar_future_days())
	return start.strftime('%Y-%m-%d'), finish.strftime('%Y-%m-%d')

def mdblist_get_my_calendar(recently_aired, current_date):
	# Mire Sirens: composed Calendar replacement for trakt_get_my_calendar(), built as
	# close to Trakt's original shape as possible per user request (not the lighter
	# /upnext-based approach). Trakt's /calendars/my/shows endpoint doesn't exist on
	# MDBList, and MDBList's own /calendar isn't in the documented API, so this composes
	# it client-side: TV Watchlist + TV Collection (MDBList) + per-show episode air dates
	# (TMDB), filtered to the active date window. Unlike a /upnext-based version, this
	# isn't limited to shows already started - the whole watchlist+collection is checked,
	# same as Trakt's original scope. Cache key embeds the date window so it rotates
	# automatically once per day without needing a background clear job.
	#
	# BUGFIX: originally only pulled from Watchlist. Reported blank Calendar despite a
	# populated MDBList — turned out the user tracks their shows via Collection ("my
	# library"), not MDBList's separate Watchlist feature, so Watchlist-only was always
	# going to be empty for them. Now merges both sources (deduped by tmdb/imdb id) so
	# Calendar works regardless of which one someone actually uses.
	from modules.metadata import tvshow_meta, episodes_meta
	start_str, finish_str = _mdblist_calendar_days(recently_aired, current_date)
	def _build(dummy):
		api_key, mpaa_region_value = settings.tmdb_api_key(), settings.mpaa_region()
		watchlist = mdblist_watchlist_fetch('tvshow')
		collection = mdblist_fetch_collection('tvshow')
		seen_shows, shows = set(), []
		for item in (watchlist or []) + (collection or []):
			media_ids = item.get('media_ids') or {}
			dedup_key = media_ids.get('tmdb') or media_ids.get('imdb') or media_ids.get('tvdb')
			if not dedup_key or dedup_key in seen_shows: continue
			seen_shows.add(dedup_key)
			shows.append(item)
		processed, seen = [], set()
		def _process_show(_position, item):
			try:
				media_ids = item.get('media_ids') or {}
				if not media_ids.get('tmdb') and not media_ids.get('imdb') and not media_ids.get('tvdb'): return
				meta = tvshow_meta('trakt_dict', media_ids, api_key, mpaa_region_value, current_date)
				if not meta or meta.get('blank_entry'): return
				extra_info = meta.get('extra_info') or {}
				next_ep, last_ep = extra_info.get('next_episode_to_air'), extra_info.get('last_episode_to_air')
				seasons = set()
				if next_ep and next_ep.get('season_number') is not None: seasons.add(int(next_ep['season_number']))
				if last_ep and last_ep.get('season_number') is not None: seasons.add(int(last_ep['season_number']))
				if not seasons: return
				show_title, show_ids = meta.get('title', ''), {'tmdb': meta.get('tmdb_id', ''), 'imdb': meta.get('imdb_id', ''), 'tvdb': meta.get('tvdb_id', '')}
				for season in seasons:
					try: episodes = episodes_meta(season, meta)
					except: continue
					for ep in episodes or []:
						premiered = ep.get('premiered')
						if not premiered or not (start_str <= premiered <= finish_str): continue
						season_no, episode_no = ep.get('season'), ep.get('episode')
						if season_no is None or episode_no is None: continue
						dedup_key = (show_ids['tmdb'], season_no, episode_no)
						if dedup_key in seen: continue
						seen.add(dedup_key)
						processed.append({
							'sort_title': '%s s%s e%s' % (show_title, str(season_no).zfill(2), str(episode_no).zfill(2)),
							'media_ids': show_ids, 'season': season_no, 'episode': episode_no, 'first_aired': premiered
						})
			except Exception as e:
				kodi_utils.logger('Mire Sirens Calendar item skipped', str(e))
		# Capped independently of settings.max_threads() (which defaults to 60) - a large
		# Watchlist/Collection firing 60 concurrent TMDB requests is exactly what was
		# triggering the widespread rate-limiting/empty-result bug above. 15 is enough
		# concurrency to stay fast without hammering TMDB's per-second limit.
		threads = TaskPool().tasks_enumerate(_process_show, shows, min(len(shows), 15)) if shows else []
		[i.join() for i in threads]
		return processed
	string = 'mdblist_get_my_calendar_%s_%s' % (start_str, finish_str)
	return mdblist_cache.cache_mdblist_object(_build, string, 'dummy')

def _flatten_watchlist_ids(nested_items):
	# Mire Sirens: call sites (dialogs.py) build the same {'ids': {...}} shape used for
	# sync/watched and sync/collection. MDBList's watchlist endpoint wants the ids dict
	# directly with no 'ids' wrapper (confirmed against the scrobbler's modify_watchlist).
	return [item.get('ids', {}) for item in nested_items if item.get('ids')]

def add_to_watchlist(data):
	for key in ('movies', 'shows'):
		items = data.get(key)
		if not items: continue
		payload = {key: _flatten_watchlist_ids(items)}
		result = call_mdblist('watchlist/items/add', data=payload, method='post')
		clear_mdblist_watchlist_cache(key)
		if result is None: return notification('Error', 3000)
	return notification('Success', 3000)

def remove_from_watchlist(data):
	for key in ('movies', 'shows'):
		items = data.get(key)
		if not items: continue
		payload = {key: _flatten_watchlist_ids(items)}
		result = call_mdblist('watchlist/items/remove', data=payload, method='post')
		clear_mdblist_watchlist_cache(key)
		if result is None: return notification('Error', 3000)
	notification('Success', 3000)
	if kodi_utils.path_check('mdblist_watchlist') or kodi_utils.external(): kodi_utils.kodi_refresh()

def mdblist_sync_activities():
	# Lightweight "what changed" check — mirrors trakt_sync_activities(). Not yet wired into
	# a periodic sync loop; currently only called after writes to nudge future cache logic.
	return call_mdblist('sync/activities', method='get')

# --- Watched history (In Progress / Watched TV shows) ---
# GAP FOUND (reported: "In Progress" under TV Shows not working, called out as the user's
# most important list): watched_status.py's watched_info_tvshow()/watched_info_movie() used
# to read from a local SQLite cache (the 'watched' table in trakt_db) that was ONLY ever
# populated by Trakt's old periodic sync job (TraktMonitor in service.py). That job was
# neutralized when Trakt was removed earlier in this migration, and no MDBList equivalent
# was ever built to take its place — so under MDBList mode that local table has been
# permanently empty this whole time, independent of anything else fixed so far. "In
# Progress"/"Watched" TV shows could never have worked.
#
# Fixed properly instead of patching around it: confirmed against Umbrella's working code
# that GET /sync/watched (with since/limit/offset, cursor-style pagination via
# pagination.has_more) returns exactly what's needed — {'movies': [{'movie': {...,
# 'ids': {...}}, 'last_watched_at': ...}], 'episodes': [{'episode': {'season':, 'number':,
# 'show': {'ids': {...}}}, 'last_watched_at': ...}], 'pagination': {'has_more': bool}}.
# This queries that directly and aggregates it into the same shape
# watched_info_tvshow()/watched_info_movie() already returned, so nothing downstream needs
# to change. STILL NOT LIVE-TESTED (sandbox can't reach api.mdblist.com).
def _mdblist_fetch_watched_history():
	def _process(dummy):
		offset, limit, movies, episodes, got_response = 0, 1000, [], [], False
		while True:
			data = call_mdblist('sync/watched', params={'since': '1970-01-01T00:00:00Z', 'limit': limit, 'offset': offset}, method='get')
			if data is None:
				if not got_response: return None
				break
			got_response = True
			movies.extend(data.get('movies') or [])
			episodes.extend(data.get('episodes') or [])
			if not (data.get('pagination') or {}).get('has_more'): break
			offset += limit
		return {'movies': movies, 'episodes': episodes}
	return mdblist_cache.cache_mdblist_object(_process, 'mdblist_watched_history', 'dummy')

def mdblist_watched_shows_summary():
	# One row per show: total watched-episode count + most recent watched season/episode +
	# last_watched_at — same shape watched_status.watched_info_tvshow() used to return from
	# the local cache, keyed by tmdb id (string) to match how it's looked up downstream.
	history = _mdblist_fetch_watched_history()
	if not history: return {}
	shows = {}
	for item in history.get('episodes') or []:
		ep = item.get('episode') or {}
		show_ids = (ep.get('show') or {}).get('ids') or {}
		tmdb_id = show_ids.get('tmdb')
		if not tmdb_id: continue
		key = str(tmdb_id)
		entry = shows.setdefault(key, {'media_id': key, 'season': None, 'episode': None, 'title': '', 'last_played': '', 'total_played': 0})
		entry['total_played'] += 1
		last_watched = item.get('last_watched_at') or ''
		if last_watched > (entry['last_played'] or ''):
			entry['last_played'] = last_watched
			entry['season'], entry['episode'] = ep.get('season'), ep.get('number')
	return shows

def mdblist_watched_movies_summary():
	# Same idea for movies: one row per movie, keyed by tmdb id (string).
	history = _mdblist_fetch_watched_history()
	if not history: return {}
	movies = {}
	for item in history.get('movies') or []:
		movie = item.get('movie') or {}
		ids = movie.get('ids') or {}
		tmdb_id = ids.get('tmdb')
		if not tmdb_id: continue
		key = str(tmdb_id)
		movies[key] = {'media_id': key, 'title': movie.get('title', ''), 'last_played': item.get('last_watched_at') or ''}
	return movies

def mdblist_recently_watched_episodes():
	# Flat, per-episode view of watched history (not aggregated per-show like
	# mdblist_watched_shows_summary above) — needed by watched_status.get_recently_watched
	# ('episode'), used for features like TV-based "Because You Watched" that need an
	# actual last-watched episode as a seed. No title here (MDBList's watched history
	# doesn't reliably include one for episodes, confirmed by Umbrella's own parsing of
	# this same endpoint not extracting one either) — caller fills that in via TMDB.
	history = _mdblist_fetch_watched_history()
	if not history: return []
	results = []
	for item in history.get('episodes') or []:
		ep = item.get('episode') or {}
		show_ids = (ep.get('show') or {}).get('ids') or {}
		tmdb_id = show_ids.get('tmdb')
		if not tmdb_id: continue
		try:
			results.append({'media_ids': {'tmdb': int(tmdb_id)}, 'season': int(ep.get('season')), 'episode': int(ep.get('number')),
							'title': '', 'last_played': item.get('last_watched_at') or ''})
		except: continue
	return results

def mdblist_watched_episodes_for_show(media_id):
	# BUGFIX: watched_status.watched_info_episode() was unconditionally querying the same
	# dead local table regardless of MDBList mode — missed in the first pass of this fix,
	# and just as important since it drives the watched/unwatched checkmark on every
	# individual episode in episode-list screens (not just In Progress/Watched menus).
	# Returns [(season, episode), ...] for one show, same shape the local query returned.
	history = _mdblist_fetch_watched_history()
	if not history: return []
	result = []
	for item in history.get('episodes') or []:
		ep = item.get('episode') or {}
		show_ids = (ep.get('show') or {}).get('ids') or {}
		if str(show_ids.get('tmdb', '')) != str(media_id): continue
		try: result.append((int(ep.get('season')), int(ep.get('number'))))
		except: continue
	return result

def mdblist_watched_season_counts(media_id):
	# Same bugfix as above, for watched_status.watched_info_season() — drives per-season
	# watched-episode counts on season-list screens. Returns {season_number: count}.
	counts = {}
	for season, _ep in mdblist_watched_episodes_for_show(media_id):
		counts[season] = counts.get(season, 0) + 1
	return counts

# --- Playback resume position ("Continue Watching" for movies/episodes) ---
# Same class of gap as watched history above: watched_status.py's get_bookmarks_movie/
# get_bookmarks_episode/get_in_progress_movies/get_in_progress_episodes all read from a
# local 'progress' table that was only ever populated by Trakt's old sync job — permanently
# empty under MDBList mode since that job was neutralized. Confirmed against Umbrella's
# working code that GET /sync/playback returns a flat list (no pagination needed - it's
# just current bookmarks, not full history) shaped like: [{'id':, 'type': 'episode' or
# else movie, 'progress': percent, 'paused_at': ..., 'show': {'ids':{...}}, 'episode':
# {'season':,'number':}, 'movie': {'ids':{...}, 'title':...}}, ...]. STILL NOT
# LIVE-TESTED. Note: MDBList doesn't provide an exact playback-seconds figure (only
# percent), so the 'curr_time' field these helpers used to carry is omitted - checked
# every read site in this file and it's only ever stored, never actually read back for
# resume calculations (get_resume_seconds derives seconds from percent + duration).
def mdblist_get_playback_bookmarks():
	def _process(dummy):
		items = call_mdblist('sync/playback', method='get')
		if items is None: return None
		bookmarks = []
		for i in items or []:
			resume_id, percent, paused_at = str(i.get('id', '')), i.get('progress', '0'), i.get('paused_at', '')
			if i.get('type') == 'episode':
				show_ids = (i.get('show') or {}).get('ids') or {}
				ep = i.get('episode') or {}
				bookmarks.append({'type': 'episode', 'resume_id': resume_id, 'resume_point': percent, 'paused_at': paused_at,
					'tmdb': show_ids.get('tmdb', ''), 'imdb': show_ids.get('imdb', ''), 'tvdb': show_ids.get('tvdb', ''),
					'season': ep.get('season'), 'episode': ep.get('number'), 'title': ep.get('title', '')})
			else:
				movie = i.get('movie') or {}
				movie_ids = movie.get('ids') or {}
				bookmarks.append({'type': 'movie', 'resume_id': resume_id, 'resume_point': percent, 'paused_at': paused_at,
					'tmdb': movie_ids.get('tmdb', ''), 'imdb': movie_ids.get('imdb', ''), 'title': movie.get('title', '')})
		return bookmarks or None
	return mdblist_cache.cache_mdblist_object(_process, 'mdblist_playback_bookmarks', 'dummy')

def mdblist_bookmarks_movie():
	# Same return shape as watched_status.get_bookmarks_movie(): {tmdb_id: {'media_id',
	# 'resume_point', 'curr_time', 'resume_id'}}.
	bookmarks = mdblist_get_playback_bookmarks() or []
	return {str(b['tmdb']): {'media_id': str(b['tmdb']), 'resume_point': b['resume_point'], 'curr_time': None, 'resume_id': b['resume_id']}
			for b in bookmarks if b['type'] == 'movie' and b.get('tmdb')}

def mdblist_bookmarks_episode(media_id, season):
	# Same return shape as watched_status.get_bookmarks_episode(): {episode_number:
	# {'resume_point', 'curr_time', 'resume_id'}}, filtered to one show+season.
	bookmarks = mdblist_get_playback_bookmarks() or []
	try: season = int(season)
	except: pass
	return {b['episode']: {'resume_point': b['resume_point'], 'curr_time': None, 'resume_id': b['resume_id']}
			for b in bookmarks if b['type'] == 'episode' and str(b.get('tmdb')) == str(media_id) and b.get('season') == season and b.get('episode') is not None}

def mdblist_in_progress_movies():
	# Same return shape as watched_status.get_in_progress_movies(): list of {'media_id',
	# 'title', 'last_played'}.
	bookmarks = mdblist_get_playback_bookmarks() or []
	return [{'media_id': str(b['tmdb']), 'title': b.get('title', ''), 'last_played': b.get('paused_at') or ''}
			for b in bookmarks if b['type'] == 'movie' and b.get('tmdb')]

def mdblist_in_progress_episodes():
	# Same return shape as watched_status.get_in_progress_episodes(): list of {'media_ids',
	# 'season', 'episode', 'resume_point', 'date', 'title'}.
	bookmarks = mdblist_get_playback_bookmarks() or []
	results = []
	for b in bookmarks:
		if b['type'] != 'episode' or not b.get('tmdb') or b.get('season') is None or b.get('episode') is None: continue
		try:
			results.append({'media_ids': {'tmdb': b['tmdb']}, 'season': int(b['season']), 'episode': int(b['episode']),
							'resume_point': float(b['resume_point'] or 0), 'date': b.get('paused_at') or '', 'title': b.get('title', '')})
		except: continue
	return results

# --- Curated-list discovery (Trending / Most Watched / Top 10 Box Office) ---
# These mirror Trakt's own stats but are hosted as public MDBList lists, so no Trakt
# account is needed. Resolved via api.mdblist.com the same way any other MDBList list is:
# look up the numeric list id, then fetch its items. Same API key auth as everything else.
#
# BUGFIX (blank Trending/Box Office/TV lists): two compounding issues found on review.
# (1) cache_mdblist_object() has no real expiration (the `expiration` param is accepted
# but never used) and does `function(params) or []` before caching — so if resolution
# ever fails once, an empty result gets written to the cache and stays there permanently,
# since these curated lists have no write-path invalidation call like Collection/Watchlist
# do. (2) CURATED_LIST_CANDIDATES below was a set of guessed (user, slug) pairs found by
# browsing mdblist.com/toplists, and only the movies_most_watched/linaspurinis entry has
# been externally confirmed (matches the Kometa wiki's own MDBList docs example) — the
# rest (box office, tv_trending, tv_most_watched, anime) were never verified and are the
# likely reason those specific lists 404'd, got cached as empty, and stayed that way.
#
# UPDATE: got hold of Umbrella's actual source (a real, published, working Kodi addon
# that integrates MDBList) and confirmed api.mdblist.com has a dedicated /lists/official
# endpoint plus /lists/official/<slug>/items?mediatype=movie|show&page=N — see
# mdblist_get_official_lists/_official_list_slug/_curated_list_items_official further
# down, now the PRIMARY resolution path. CURATED_LIST_CANDIDATES below (guessed
# third-party curator accounts) and the generic lists/search fallback are kept only as a
# second-tier fallback for cases with no official-list match (currently just anime).
#
# IMPORTANT: because the OLD buggy caching may have already stored a permanent empty
# result on Harleen's install from before this fix, "Clear MDBList Cache" in Settings
# needs to be run once after updating, or these will still show blank despite the fix.
#
# STILL NOT LIVE-TESTED (sandbox can't reach api.mdblist.com) — verify against a real key
# and report back.
CURATED_LIST_CANDIDATES = {
	'movies_trending': (('linaspurinis', 'trending-movies-list'), ('snoak', 'trending-movies')),
	'movies_most_watched': (('linaspurinis', 'top-watched-movies-of-the-week'), ('jah57', 'trakt-most-watched-movies-of-the-week')),
	'movies_top10_boxoffice': (('linaspurinis', 'box-office-50'), ('linaspurinis', 'box-office-60')),
	'tv_trending': (('snoak', 'trakt-s-trending-shows'),),
	'tv_most_watched': (('jah57', 'trakt-most-watched-shows-of-the-week'), ('shadowacex', 'most-watched-shows-weekly')),
	# Mire Sirens: anime bucket, added when removing trakt_anime_* for the full Trakt
	# teardown. Trending has decent live evidence (3 different curators independently
	# maintain a "Trakt Anime Trending" mirror list). Most Watched (anime) has NO found
	# equivalent anywhere on mdblist.com/toplists or targeted search — Trakt's own
	# shows/watched/daily?genres=anime concept doesn't appear to have a public mirror list
	# under any curator account. Left unimplemented (see mdblist_anime_most_watched below,
	# which is a stub, not wired into any menu) until Harleen decides how to handle it —
	# same fork in the road as Most Favorited: drop the menu entry, or accept a
	# popularity-based TMDB proxy that isn't really the same metric.
	'anime_trending': (('snoak', 'trending-anime-shows'), ('tvgeniekodi', 'trending-anime-tv-shows'), ('tubeman', 'trakt-anime-trending-tv-shows')),
}

# Exact names MDBList's own docs (docs.mdblist.com/docs/popular_lists) list as their
# officially maintained "Popular lists" — used to match against /lists/official below.
# No equivalent officially-named list exists for anime, so no entry here for that key.
CURATED_LIST_SEARCH_NAMES = {
	'movies_trending': 'Trakt Trending Movies',
	'movies_most_watched': 'Trakt Most Watched Movies',
	'movies_top10_boxoffice': 'Trakt Weekend Box Office',
	'tv_trending': 'Trakt Trending TV Shows',
	'tv_most_watched': 'Trakt Most Watched TV Shows',
}

# Which MDBList mediatype each curated key needs when fetching from an official list
# (required query param on /lists/official/<slug>/items).
CURATED_LIST_MEDIATYPE = {
	'movies_trending': 'movie', 'movies_most_watched': 'movie', 'movies_top10_boxoffice': 'movie',
	'tv_trending': 'show', 'tv_most_watched': 'show',
}

# CONFIRMED against a real, published, working Kodi addon (Umbrella) that integrates
# MDBList: api.mdblist.com genuinely has a dedicated /lists/official endpoint (returns
# all of MDBList's own maintained lists as {'name','slug','id','items',...} dicts) plus a
# slug-keyed items endpoint /lists/official/<slug>/items?mediatype=movie|show&page=N. This
# is the authoritative, first-choice way to resolve Trending/Box Office/Most Watched —
# far more reliable than guessing which third-party curator account happens to host a
# similarly-named list (the CURATED_LIST_CANDIDATES/_curated_list_id_by_search approach
# below, kept only as a fallback for cases with no official-list match, e.g. anime).
def mdblist_get_official_lists():
	def _process(dummy):
		return call_mdblist('lists/official', method='get') or []
	return mdblist_cache.cache_mdblist_object(_process, 'mdblist_official_lists', 'dummy')

def _official_list_slug(list_key):
	name = CURATED_LIST_SEARCH_NAMES.get(list_key)
	if not name: return None
	for item in (mdblist_get_official_lists() or []):
		if (item.get('name') or '').strip().lower() == name.lower():
			return item.get('slug')
	return None

def _curated_list_items_official(list_key, page_no):
	slug, mediatype = _official_list_slug(list_key), CURATED_LIST_MEDIATYPE.get(list_key)
	if not slug or not mediatype: return None
	def _process(dummy):
		data = call_mdblist('lists/official/%s/items' % slug, params={'mediatype': mediatype, 'page': page_no}, method='get')
		if not data: return []
		items = data if isinstance(data, list) else (data.get('movies') or data.get('shows') or [])
		return [{'ids': {'tmdb': i.get('ids', {}).get('tmdb', ''), 'imdb': i.get('ids', {}).get('imdb', ''), 'tvdb': i.get('ids', {}).get('tvdb', '')}} for i in items]
	string = 'mdblist_curated_official_%s_%s' % (list_key, page_no)
	return mdblist_cache.cache_mdblist_object(_process, string, 'dummy')

def _user_list_slugs(user):
	def _process(dummy):
		data = call_mdblist('lists/user/%s' % user, method='get') or []
		return {i.get('slug'): i.get('id') for i in data}
	string = 'mdblist_curated_user_lists_%s' % user
	return mdblist_cache.cache_mdblist_object(_process, string, 'dummy')

def _curated_list_id_by_search(list_key):
	name = CURATED_LIST_SEARCH_NAMES.get(list_key)
	if not name: return None
	for item in (mdblist_search_lists(name) or []):
		if (item.get('name') or '').strip().lower() == name.lower():
			return item.get('id')
	return None

def _curated_list_id(list_key):
	def _process(dummy):
		for user, slug in CURATED_LIST_CANDIDATES.get(list_key, ()):
			by_slug = _user_list_slugs(user)
			if slug in by_slug: return by_slug[slug]
		return _curated_list_id_by_search(list_key)
	string = 'mdblist_curated_list_id_%s' % list_key
	return mdblist_cache.cache_mdblist_object(_process, string, 'dummy')

def _curated_list_items(list_key, page_no=1, limit=20):
	official = _curated_list_items_official(list_key, page_no)
	if official: return official
	def _process(dummy):
		list_id = _curated_list_id(list_key)
		if not list_id: return []
		params = {'limit': limit, 'offset': (int(page_no) - 1) * limit}
		data = call_mdblist('lists/%s/items' % list_id, params=params, method='get') or []
		items = data if isinstance(data, list) else (data.get('movies') or data.get('shows') or [])
		return [{'ids': {'tmdb': i.get('ids', {}).get('tmdb', ''), 'imdb': i.get('ids', {}).get('imdb', ''), 'tvdb': i.get('ids', {}).get('tvdb', '')}} for i in items]
	string = 'mdblist_curated_%s_%s' % (list_key, page_no)
	return mdblist_cache.cache_mdblist_object(_process, string, 'dummy')

def mdblist_movies_trending(page_no):
	return _curated_list_items('movies_trending', page_no)

def mdblist_movies_most_watched(page_no):
	return _curated_list_items('movies_most_watched', page_no)

def mdblist_movies_top10_boxoffice(page_no):
	return _curated_list_items('movies_top10_boxoffice', page_no)

def mdblist_tv_trending(page_no):
	return _curated_list_items('tv_trending', page_no)

def mdblist_tv_most_watched(page_no):
	return _curated_list_items('tv_most_watched', page_no)

def mdblist_anime_trending(page_no):
	return _curated_list_items('anime_trending', page_no)

# --- Public/personal list browsing (bucket 3: replaces trakt_lists.py's dependency on
# trakt_api.py's list-management functions) ---
# Mapped against MDBList's official API docs (github.com/linaspurinis/api.mdblist.com).
# Deliberately NOT ported, because no MDBList equivalent exists:
#   - "Liked Lists" - no per-user liked-lists concept in the API
#   - Like/Unlike a list - no like/unlike endpoint at all (the "likes" count on a list is
#     read-only, inherited from Trakt import data)
#   - "In Trakt Lists" (which public lists a given movie/show appears in) - no such lookup
# Trakt's separate "Trending User Lists" / "Popular User Lists" browses are collapsed into
# a single mdblist_get_popular_lists() below, since MDBList only exposes one such feed
# (lists/top, "sorted by Trakt likes") rather than two distinct facets.

def mdblist_search_lists(query):
	def _process(dummy):
		return call_mdblist('lists/search', params={'query': query}, method='get') or []
	string = 'mdblist_search_lists_%s' % query
	return mdblist_cache.cache_mdblist_object(_process, string, 'dummy')

def mdblist_get_my_lists():
	def _process(dummy):
		return call_mdblist('lists/user', params={'sort': 'ranked'}, method='get') or []
	return mdblist_cache.cache_mdblist_object(_process, 'mdblist_my_lists', 'dummy')

def mdblist_get_popular_lists():
	def _process(dummy):
		return call_mdblist('lists/top', method='get') or []
	return mdblist_cache.cache_mdblist_object(_process, 'mdblist_popular_lists', 'dummy')

def _normalize_list_items(data):
	results = []
	results_append = results.append
	order = 0
	for key, media_type in (('movies', 'movie'), ('shows', 'show')):
		for item in (data or {}).get(key, []) or []:
			try:
				ids = item.get('ids', {})
				results_append({'media_ids': {'tmdb': ids.get('tmdb', ''), 'imdb': ids.get('imdb', ''), 'tvdb': ids.get('tvdb', '')},
					'title': item.get('title', ''), 'type': media_type, 'order': order, 'released': item.get('release_year', '')})
				order += 1
			except: pass
	return results

def mdblist_list_contents(list_id=None, user=None, slug=None, sort_by='rank', sort_how='asc'):
	# Mirrors get_trakt_list_contents' call shape (list_id OR user+slug) but MDBList lists
	# are movie/show level only - no season/episode granularity to thread through.
	if list_id is not None:
		string, path = 'mdblist_list_contents_%s' % list_id, 'lists/%s/items' % list_id
	else:
		string, path = 'mdblist_list_contents_%s_%s' % (user, slug), 'lists/%s/%s/items' % (user, slug)
	def _process(dummy):
		data = call_mdblist(path, params={'sort': sort_by, 'order': sort_how, 'limit': 1000}, method='get')
		return _normalize_list_items(data)
	return mdblist_cache.cache_mdblist_object(_process, string, 'dummy')

def mdblist_make_new_list(name, private=False):
	result = call_mdblist('lists/user/add', data={'name': name, 'private': private}, method='post')
	if result is None: return notification('Error', 3000)
	notification('Success', 3000)
	return result

def mdblist_delete_list(list_id):
	result = call_mdblist('lists/%s' % list_id, method='delete')
	if result is None: return notification('Error', 3000)
	notification('Success', 3000)
	return result

def mdblist_add_list_items(list_id, data):
	result = call_mdblist('lists/%s/items/add' % list_id, data=data, method='post')
	mdblist_cache.mdblist_cache.delete('mdblist_list_contents_%s' % list_id)
	if result is None: return notification('Error', 3000)
	notification('Success', 3000)
	return result

def mdblist_remove_list_items(list_id, data):
	result = call_mdblist('lists/%s/items/remove' % list_id, data=data, method='post')
	mdblist_cache.mdblist_cache.delete('mdblist_list_contents_%s' % list_id)
	if result is None: return notification('Error', 3000)
	notification('Success', 3000)
	return result

def mdblist_get_list_selection():
	# Mire Sirens: MDBList equivalent of trakt_api.get_trakt_list_selection(['personal']) —
	# used by dialogs.mdblist_manager_choice's "Add/Remove Personal List" option. MDBList has
	# no "liked lists" concept (see the bucket-3 note above), so this only ever covers the
	# user's own lists, unlike Trakt's version which could also include a 'liked' set.
	my_lists = mdblist_get_my_lists()
	used_lists = [{'name': item['name'], 'display': '[B]PERSONAL:[/B] [I]%s[/I]' % item['name'].upper(), 'list_id': item['id'], 'item_count': item['items']}
		for item in my_lists]
	used_lists.sort(key=lambda k: k['name'])
	if not used_lists: return None
	list_items = [{'line1': '%s [I](x%02d)[/I]' % (item['display'], item['item_count'])} for item in used_lists]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Select', 'narrow_window': 'true'}
	selection = kodi_utils.select_dialog(used_lists, **kwargs)
	if selection == None: return None
	return selection

def mdblist_get_import_list_selection():
	# Mire Sirens: MDBList equivalent of trakt_api.get_trakt_list_selection(['default',
	# 'personal', 'liked']) — used by the "Import a Trakt List" flows in personal_lists.py
	# and tmdb_lists.py. 'default' (Collection/Watchlist pseudo-lists) and 'personal' (my
	# MDBList lists) are covered; 'liked' has no equivalent (see the bucket-3 note above)
	# so it's simply not offered as a choice.
	default_lists = [
		{'name': 'Movies Collection', 'display': '[B][I]MOVIES COLLECTION [/I][/B]', 'list_type': 'collection', 'media_type': 'movie'},
		{'name': 'TV Show Collection', 'display': '[B][I]TV SHOW COLLECTION [/I][/B]', 'list_type': 'collection', 'media_type': 'show'},
		{'name': 'Movies Watchlist', 'display': '[B][I]MOVIES WATCHLIST [/I][/B]', 'list_type': 'watchlist', 'media_type': 'movie'},
		{'name': 'TV Show Watchlist', 'display': '[B][I]TV SHOW WATCHLIST [/I][/B]', 'list_type': 'watchlist', 'media_type': 'show'},
	]
	personal = [{'name': item['name'], 'display': '[B]PERSONAL:[/B] [I]%s[/I]' % item['name'].upper(), 'list_type': 'my_lists', 'list_id': item['id'],
		'item_count': item['items']} for item in mdblist_get_my_lists()]
	personal.sort(key=lambda k: k['name'])
	used_lists = default_lists + personal
	list_items = [{'line1': '%s%s' % (item['display'], ' [I](x%02d)[/I]' % item['item_count'] if 'item_count' in item else '')} for item in used_lists]
	kwargs = {'items': json.dumps(list_items), 'heading': 'Select', 'narrow_window': 'true'}
	selection = kodi_utils.select_dialog(used_lists, **kwargs)
	if selection == None: return None
	return selection

def process_mdblist_list(chosen_list):
	# Mire Sirens: MDBList equivalent of trakt_lists.process_trakt_list (duplicated in
	# personal_lists.py and tmdb_lists.py) - shared here so both callers use one version.
	# Note: MDBList's collection/watchlist sync doesn't return a release date the way
	# Trakt's extended data did, so release_date is left blank for that branch.
	media_type_check = {'movie': 'movie', 'show': 'tvshow', 'tvshow': 'tvshow'}
	new_contents = []
	current_timestamp = get_current_timestamp()
	list_type = chosen_list.get('list_type')
	if list_type in ('collection', 'watchlist'):
		media_type = chosen_list.get('media_type')
		fetch = mdblist_fetch_collection if list_type == 'collection' else mdblist_watchlist_fetch
		result = fetch(media_type)
		try:
			sort_order = settings.lists_sort_order(list_type)
			if sort_order == 0: result = sort_for_article(result, 'title', settings.ignore_articles())
			elif sort_order == 1: result.sort(key=lambda k: k.get('collected_at') or k.get('listed_at') or '', reverse=True)
			else: result.sort(key=lambda k: k.get('released') or '', reverse=True)
		except: pass
		for count, item in enumerate(result):
			try:
				media_id = item['media_ids']['tmdb']
				if media_id in (None, 'None', ''): continue
				new_contents.append({'media_id': str(media_id), 'title': item['title'], 'type': media_type_check[media_type],
					'release_date': '', 'date_added': str(current_timestamp + count)})
			except: continue
	else:
		list_id = chosen_list.get('list_id')
		result = mdblist_list_contents(list_id=list_id)
		try: result.sort(key=lambda k: k['order'])
		except: pass
		for count, item in enumerate(result):
			try:
				media_id = item['media_ids']['tmdb']
				if media_id in (None, 'None', ''): continue
				release_date = str(item.get('released') or '')
				new_contents.append({'media_id': str(media_id), 'title': item['title'], 'type': media_type_check[item['type']],
					'release_date': release_date, 'date_added': str(current_timestamp + count)})
			except: continue
	return new_contents
